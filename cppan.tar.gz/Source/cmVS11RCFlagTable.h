static cmVS7FlagTable cmVS11RCFlagTable[] = {
  // Bool Properties
  { "NullTerminateStrings", "n", "", "true", 0 },
  { "SuppressStartupBanner", "nologo", "", "true", 0 },

  { 0, 0, 0, 0, 0 }
};
